# JZ 记账

AstrBot 收支记账插件。使用 `JZ` 前缀记录消费和收入，支持按自然月查询、统计、预算提醒、月度结算和 CSV 导出。

## 安装

1. 在 AstrBot 插件管理页面上传 `astrbot_plugin_bookkeeping.zip`。
2. 安装后按需修改插件配置。
3. 重载插件或重启 AstrBot。

## 基本用法

记账：

- `JZ，早饭 7.5 元`
- `JZ, 工资 5000`
- `JZ，昨天午饭 25`
- `JZ，2026-09-10 房租 2000`

查询和统计：

- `JZ查 餐饮`
- `JZ查 2026-09 打车`
- `JZ统计 本月`
- `JZ月报`

修改记录：

- `JZ删除 3`
- `JZ删除 最后`
- `JZ修改 3 金额 8.5`
- `JZ修改 3 分类 交通`
- `JZ撤销`

预算和导出：

- `JZ预算 2000`
- `JZ预算`
- `JZ结算`
- `JZ导出 2026-09`
- `JZ导出 全部`

## 数据位置

运行数据保存在 AstrBot 的插件数据目录中，文件名为 `bookkeeping.json`。插件使用 JSON 原子写入和线程锁保护数据；检测到损坏文件时会先备份为 `.broken`，再重建空数据。

## 配置

- `account_scope`：`user` 按用户隔离，`group` 按群共享。
- `timezone`：默认 `Asia/Shanghai`。
- `max_list`：查询和月报最多显示的明细条数，默认 20。
- `daily_budget` / `monthly_budget`：默认每日和每月预算，0 表示不启用。
- `warn_threshold`：预算预警比例，默认 0.8。
