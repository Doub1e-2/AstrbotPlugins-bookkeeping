from __future__ import annotations

from .models import Record, RecordType
from .utils import money_text


def error(message: str, example: str = "") -> str:
    suffix = f"\n示例：{example}" if example else ""
    return f"❌ {message}{suffix}"


def record_detail(record: Record) -> str:
    return "\n".join((f"类型：{record.type}", f"分类：{record.category}", f"金额：{money_text(record.amount)} 元", f"备注：{record.note}"))


def added(record: Record, summary: dict, warnings: list[str] | None = None) -> str:
    lines = [f"✅ 已记账（{record.month}）", record_detail(record), f"本月支出：{money_text(summary['支出'])} 元 ｜ 收入：{money_text(summary['收入'])} 元"]
    lines.extend(warnings or [])
    return "\n".join(lines)


def month_report(month: str, records: list[Record], summary: dict, categories: list[dict], max_list: int = 20) -> str:
    lines = [f"📅 {month} 账单（共 {summary['笔数']} 笔）", f"支出：{money_text(summary['支出'])} 元", f"收入：{money_text(summary['收入'])} 元", f"结余：{money_text(summary['结余'])} 元", "", "分类统计："]
    lines.extend(f"{item['category']} {money_text(item['amount'])} 元" for item in categories)
    lines.extend(["", f"明细（最近 {min(max_list, len(records))} 条）："])
    for record in records[-max_list:]:
        sign = "-" if record.type == RecordType.EXPENSE.value else "+"
        lines.append(f"{record.time[5:16].replace('T', ' ')}  {record.category}  {sign}{money_text(record.amount)}  {record.note}")
    return "\n".join(lines)


def query_report(month: str, records: list[Record], total: int, max_list: int) -> str:
    lines = [f"🔎 {month} 查询结果（显示 {min(total, max_list)} / {total} 条）"]
    for index, record in enumerate(records[-max_list:], start=max(1, total - len(records[-max_list:]) + 1)):
        sign = "-" if record.type == RecordType.EXPENSE.value else "+"
        lines.append(f"{index}. {record.time[5:16].replace('T', ' ')} {record.category} {sign}{money_text(record.amount)} 元 {record.note}")
    return "\n".join(lines)


def statistics_report(month: str, records: list[Record], items: list[dict], type_name: str) -> str:
    total = sum(record.amount for record in records if record.type == type_name)
    lines = [f"📊 {month} {type_name}统计（共 {len(records)} 笔，合计 {money_text(total)} 元）"]
    lines.extend(f"{item['category']}   {money_text(item['amount'])} 元  {item['ratio']:.1%}" for item in items)
    return "\n".join(lines)


def settlement_report(value: dict) -> str:
    status = "已结算" if value.get("settled") else "进行中"
    lines = [f"📅 {value['month']} 预算结算（{status}）", f"冗余池累计：{money_text(value.get('reserve', 0))} 元", f"花超累计：{money_text(value.get('overspend', 0))} 元"]
    net = money_text(abs(value.get("net", 0)))
    lines.append(f"{'抵扣后净结余' if value.get('net', 0) >= 0 else '抵扣后净超支'}：{net} 元")
    if value.get("settled"):
        lines.append("（该月已结算，数据已清零）")
    return "\n".join(lines)
