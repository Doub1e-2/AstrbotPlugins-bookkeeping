from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from typing import Any

from .config import get_setting
from .models import Record, RecordType
from .storage import JsonStorage
from .utils import csv_text, local_now, money, parse_month


class BookkeepingService:
    def __init__(self, storage: JsonStorage, config: Any = None) -> None:
        self.storage = storage
        self.config = config or {}
        self.timezone = str(get_setting(self.config, "timezone", "Asia/Shanghai"))

    @staticmethod
    def account_key(user_id: str, group_id: str | None = None, scope: str = "user") -> str:
        return f"group:{group_id}" if scope == "group" and group_id else str(user_id)

    def key(self, user_id: str, group_id: str | None = None) -> str:
        return self.account_key(user_id, group_id, str(get_setting(self.config, "account_scope", "user")))

    async def add(self, record: Record) -> Record:
        account = await self.storage.get_account(self.key(record.user_id, record.group_id))
        budget = account.setdefault("budget", {"daily": 0.0, "monthly": 0.0})
        if not budget.get("daily"):
            budget["daily"] = max(0.0, money(get_setting(self.config, "daily_budget", 0)))
        if not budget.get("monthly"):
            budget["monthly"] = max(0.0, money(get_setting(self.config, "monthly_budget", 0)))
        account["records"].setdefault(record.month, []).append(record.to_dict())
        account["records"][record.month].sort(key=lambda value: (value.get("time", ""), value.get("id", "")))
        await self.storage.save_account(self.key(record.user_id, record.group_id), account)
        return record

    async def delete(self, user_id: str, month: str, index: int, group_id: str | None = None) -> Record:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        records = account["records"].get(parse_month(month), [])
        self._check_index(records, index)
        result = Record.from_dict(records.pop(index - 1))
        await self.storage.save_account(key, account)
        return result

    async def delete_last(self, user_id: str, month: str, group_id: str | None = None) -> Record:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        records = account["records"].get(parse_month(month), [])
        if not records:
            raise ValueError("当月没有记录")
        result = Record.from_dict(records.pop())
        await self.storage.save_account(key, account)
        return result

    async def undo_last(self, user_id: str, group_id: str | None = None) -> Record:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        candidates = [(month, record) for month, values in account["records"].items() for record in values]
        if not candidates:
            raise ValueError("没有可撤销的记录")
        month, record = max(candidates, key=lambda item: (item[1].get("time", ""), item[1].get("id", "")))
        account["records"][month].remove(record)
        await self.storage.save_account(key, account)
        return Record.from_dict(record)

    async def update(self, user_id: str, month: str, index: int, field: str, value: str, group_id: str | None = None) -> Record:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        source_month = parse_month(month)
        records = account["records"].get(source_month, [])
        self._check_index(records, index)
        record = Record.from_dict(records[index - 1])
        field_map = {"金额": "amount", "分类": "category", "备注": "note", "时间": "time", "日期": "time", "类型": "type"}
        target = field_map.get(field, field if field in {"amount", "category", "note", "time", "type"} else "")
        if not target:
            raise ValueError("支持修改：金额、分类、备注、时间、类型")
        if target == "amount":
            amount = money(value)
            if amount <= 0 or amount > 1_000_000_000:
                raise ValueError("金额必须大于 0 且不超过 1e9")
            record.amount = amount
        elif target == "time":
            try:
                changed = datetime.fromisoformat(value.strip())
            except ValueError as exc:
                raise ValueError("时间格式应为 YYYY-MM-DD 或 ISO8601") from exc
            if changed.tzinfo is None:
                changed = changed.replace(tzinfo=local_now(self.timezone).tzinfo)
            if changed > local_now(self.timezone):
                raise ValueError("不能修改为未来时间")
            record.time = changed.replace(microsecond=0).isoformat()
            record.month = record.time[:7]
        elif target == "type":
            if value not in {RecordType.EXPENSE.value, RecordType.INCOME.value, "支出", "收入"}:
                raise ValueError("类型只能是支出或收入")
            record.type = value
        else:
            setattr(record, target, str(value).strip() or "未分类")
        records.pop(index - 1)
        account["records"].setdefault(record.month, []).append(record.to_dict())
        account["records"][record.month].sort(key=lambda item: (item.get("time", ""), item.get("id", "")))
        await self.storage.save_account(key, account)
        return record

    async def move_record(self, user_id: str, from_month: str, to_month: str, record_id: str, group_id: str | None = None) -> Record:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        source, target = parse_month(from_month), parse_month(to_month)
        values = account["records"].get(source, [])
        found = next((value for value in values if value.get("id") == record_id), None)
        if found is None:
            raise ValueError("未找到要迁移的记录")
        values.remove(found)
        found["month"] = target
        account["records"].setdefault(target, []).append(found)
        await self.storage.save_account(key, account)
        return Record.from_dict(found)

    async def list_month(self, user_id: str, month: str | None = None, group_id: str | None = None) -> list[Record]:
        account = await self.storage.get_account(self.key(user_id, group_id))
        target = parse_month(month)
        return [Record.from_dict(item) for item in sorted(account["records"].get(target, []), key=lambda item: (item.get("time", ""), item.get("id", "")))]

    async def summary(self, user_id: str, month: str | None = None, group_id: str | None = None) -> dict[str, float | int]:
        records = await self.list_month(user_id, month, group_id)
        expense = sum(item.amount for item in records if item.type == RecordType.EXPENSE.value)
        income = sum(item.amount for item in records if item.type == RecordType.INCOME.value)
        return {"支出": money(expense), "收入": money(income), "结余": money(income - expense), "笔数": len(records)}

    async def category_summary(self, user_id: str, month: str | None = None, type: str = "支出", group_id: str | None = None) -> list[dict[str, float | str]]:
        records = await self.list_month(user_id, month, group_id)
        grouped: defaultdict[str, float] = defaultdict(float)
        for item in records:
            if type and item.type != type:
                continue
            grouped[item.category] += item.amount
        total = sum(grouped.values())
        return [{"category": category, "amount": money(amount), "ratio": (amount / total if total else 0)} for category, amount in sorted(grouped.items(), key=lambda item: item[1], reverse=True)]

    async def query(self, user_id: str, filters: dict[str, Any], group_id: str | None = None) -> list[Record]:
        records = await self.list_month(user_id, filters.get("month"), group_id)
        category = str(filters.get("category", "")).strip()
        keyword = str(filters.get("keyword", "")).strip().lower()
        type_name = str(filters.get("type", "")).strip()
        return [item for item in records if (not category or item.category == category) and (not type_name or item.type == type_name) and (not keyword or keyword in f"{item.category} {item.note} {item.raw}".lower())]

    async def set_budget(self, user_id: str, daily: float | None = None, monthly: float | None = None, group_id: str | None = None) -> dict[str, float]:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        budget = account.setdefault("budget", {"daily": 0.0, "monthly": 0.0})
        if daily is not None:
            budget["daily"] = max(0.0, money(daily))
        if monthly is not None:
            budget["monthly"] = max(0.0, money(monthly))
        await self.storage.save_account(key, account)
        return {"daily": float(budget.get("daily", 0)), "monthly": float(budget.get("monthly", 0))}

    async def check_budget(self, user_id: str, when: datetime, group_id: str | None = None, record_id: str | None = None) -> list[str]:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        budget = account.get("budget", {})
        month = when.strftime("%Y-%m")
        records = [Record.from_dict(value) for value in account.get("records", {}).get(month, [])]
        daily_used = sum(item.amount for item in records if item.type == RecordType.EXPENSE.value and item.time[:10] == when.date().isoformat())
        monthly_used = sum(item.amount for item in records if item.type == RecordType.EXPENSE.value)
        warnings: list[str] = []
        daily_budget, monthly_budget = float(budget.get("daily", 0)), float(budget.get("monthly", 0))
        threshold = float(get_setting(self.config, "warn_threshold", 0.8))
        if daily_budget > 0 and daily_used > daily_budget:
            warnings.append(f"⚠️ 今日已超支 {money_text(daily_used - daily_budget)} 元")
        elif daily_budget > 0 and daily_used / daily_budget >= threshold:
            warnings.append(f"⚠️ 今日预算已用 {daily_used / daily_budget:.0%}")
        if monthly_budget > 0 and monthly_used > monthly_budget:
            warnings.append(f"⚠️ 本月已超支 {money_text(monthly_used - monthly_budget)} 元")
        if record_id and warnings:
            warned = account.setdefault("meta", {}).setdefault("warned", [])
            if record_id in warned:
                warnings = []
            else:
                warned.append(record_id)
                await self.storage.save_account(key, account)
        return warnings

    async def settle_daily(self, user_id: str, when: date, group_id: str | None = None) -> dict[str, float]:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        month = when.strftime("%Y-%m")
        day = when.isoformat()
        settlement = account.setdefault("settlement", {}).setdefault(month, {"reserve": 0.0, "overspend": 0.0, "settled": False, "days": []})
        if day in settlement.setdefault("days", []):
            return {"reserve": float(settlement.get("reserve", 0)), "overspend": float(settlement.get("overspend", 0))}
        records = [Record.from_dict(value) for value in account.get("records", {}).get(month, [])]
        spent = sum(item.amount for item in records if item.type == RecordType.EXPENSE.value and item.time[:10] == day)
        daily_budget = float(account.get("budget", {}).get("daily", 0))
        if daily_budget > 0:
            if spent <= daily_budget:
                settlement["reserve"] = money(float(settlement.get("reserve", 0)) + daily_budget - spent)
            else:
                settlement["overspend"] = money(float(settlement.get("overspend", 0)) + spent - daily_budget)
        settlement["days"].append(day)
        await self.storage.save_account(key, account)
        return {"reserve": float(settlement.get("reserve", 0)), "overspend": float(settlement.get("overspend", 0))}

    async def settle_month(self, user_id: str, month: str, group_id: str | None = None) -> dict[str, Any]:
        key = self.key(user_id, group_id)
        account = await self.storage.get_account(key)
        month = parse_month(month)
        settlement = account.setdefault("settlement", {}).setdefault(month, {"reserve": 0.0, "overspend": 0.0, "settled": False, "days": []})
        reserve, overspend = money(settlement.get("reserve", 0)), money(settlement.get("overspend", 0))
        net = money(reserve - overspend)
        settlement["history"] = {"reserve": reserve, "overspend": overspend, "net": net}
        settlement["reserve"], settlement["overspend"], settlement["settled"] = 0.0, 0.0, True
        await self.storage.save_account(key, account)
        return await self.query_month_settlement(user_id, month, group_id)

    async def query_month_settlement(self, user_id: str, month: str, group_id: str | None = None) -> dict[str, Any]:
        account = await self.storage.get_account(self.key(user_id, group_id))
        month = parse_month(month)
        value = account.get("settlement", {}).get(month, {"reserve": 0.0, "overspend": 0.0, "settled": False})
        if value.get("settled") and value.get("history"):
            current = value["history"]
        else:
            current = {"reserve": float(value.get("reserve", 0)), "overspend": float(value.get("overspend", 0)), "net": money(float(value.get("reserve", 0)) - float(value.get("overspend", 0)))}
        return {**current, "settled": bool(value.get("settled", False)), "month": month}

    async def export(self, user_id: str, month: str | None = None, group_id: str | None = None) -> str:
        if month == "全部":
            account = await self.storage.get_account(self.key(user_id, group_id))
            values = [item for records in account.get("records", {}).values() for item in records]
        else:
            values = [item.to_dict() for item in await self.list_month(user_id, month, group_id)]
        return csv_text(values)

    @staticmethod
    def _check_index(records: list[dict], index: int) -> None:
        if index < 1 or index > len(records):
            raise ValueError(f"❌ 序号超出范围，当月共 {len(records)} 笔")


def money_text(value: float) -> str:
    return f"{money(value):.2f}"
