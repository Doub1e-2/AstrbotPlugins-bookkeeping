from __future__ import annotations

import re
import time
import uuid
from datetime import datetime
from typing import Iterable

from .config import DEFAULT_CATEGORIES
from .models import Record, RecordType
from .utils import money, parse_date_text


DATE_RE = re.compile(r"大前天|昨天|前天|今天|今日|本周[一二三四五六日天1-7]|上周[一二三四五六日天1-7]|\d{4}-\d{1,2}-\d{1,2}|\d{1,2}月\d{1,2}日?|\d{1,2}/\d{1,2}")
AMOUNT_WITH_UNIT_RE = re.compile(r"(?P<sign>[+-])?\s*(?P<amount>\d+(?:\.\d+)?)\s*(?:元|块钱|块|￥|¥|rmb)", re.I)
AMOUNT_RE = re.compile(r"(?P<sign>[+-])?\s*(?P<amount>\d+(?:\.\d+)?)")
INCOME_WORDS = ("工资", "奖金", "报销", "红包", "退款", "利息", "进账", "到账", "赚", "卖了", "卖掉")


def _categories(value: dict[str, Iterable[str]] | None) -> dict[str, list[str]]:
    return {str(k): [str(x) for x in v] for k, v in (value or DEFAULT_CATEGORIES).items()}


def _date_match(text: str, now: datetime) -> tuple[datetime, str] | None:
    match = DATE_RE.search(text)
    if not match:
        return None
    token = match.group(0)
    try:
        return parse_date_text(token, now, date_only=True), token
    except ValueError as exc:
        raise ValueError(str(exc)) from exc


def parse_record(
    text: str,
    user_id: str = "",
    group_id: str | None = None,
    now: datetime | None = None,
    categories: dict[str, Iterable[str]] | None = None,
) -> Record:
    """Parse one bookkeeping sentence without reading storage or global state."""
    raw = (text or "").strip()
    if not raw or not re.search(r"\w|[\u4e00-\u9fff]", raw):
        raise ValueError("请输入记账内容，例如：早饭 7.5 元")
    current = now or datetime.now().astimezone().replace(microsecond=0)
    working = raw
    parsed_date = _date_match(working, current)
    record_time = parsed_date[0] if parsed_date else current
    if parsed_date:
        if record_time.date() > current.date():
            raise ValueError("❌ 不能记录未来日期")
        working = working.replace(parsed_date[1], " ", 1)

    amount_match = next(iter(AMOUNT_WITH_UNIT_RE.finditer(working)), None)
    if amount_match is None:
        amount_match = next(iter(AMOUNT_RE.finditer(working)), None)
    if amount_match is None:
        raise ValueError("未识别到金额，请补充金额，例如：午饭 25 元")
    amount = money(amount_match.group("amount"))
    if amount <= 0:
        raise ValueError("金额必须大于 0")
    if amount > 1_000_000_000:
        raise ValueError("金额不能超过 1e9 元")

    sign = amount_match.group("sign")
    type_name = RecordType.INCOME.value if (sign == "+" or any(word in raw for word in INCOME_WORDS)) else RecordType.EXPENSE.value
    if sign == "-":
        type_name = RecordType.EXPENSE.value
    amount_text = amount_match.group(0)
    working = working[:amount_match.start()] + " " + working[amount_match.end():]
    category = "未分类"
    for name, words in _categories(categories).items():
        if any(word and word in raw for word in words):
            category = name
            break
    note = working.strip(" \t，,。；;:：-+()（）[]【】")
    if not note:
        note = raw
    timestamp = record_time.replace(microsecond=0).isoformat()
    return Record(
        id=f"{time.time_ns()}-{uuid.uuid4().hex[:8]}",
        user_id=str(user_id), group_id=group_id, amount=amount, type=type_name,
        category=category, note=note, raw=raw, time=timestamp, month=timestamp[:7],
    )
