import asyncio
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from astrbot_plugin_bookkeeping.parser import parse_record
from astrbot_plugin_bookkeeping.service import BookkeepingService
from astrbot_plugin_bookkeeping.storage import JsonStorage


class BookkeepingTests(unittest.TestCase):
  def test_parser_examples(self):
    now = datetime.fromisoformat("2026-09-16T10:00:00+08:00")
    cases = {
        "早饭消费7.5元": ("支出", "餐饮", 7.5, "2026-09"),
        "工资 5000": ("收入", "收入", 5000.0, "2026-09"),
        "昨天午饭25": ("支出", "餐饮", 25.0, "2026-09"),
        "2026-09-10 房租 2000": ("支出", "居住", 2000.0, "2026-09"),
    }
    for text, expected in cases.items():
      record = parse_record(text, user_id="u", now=now)
      self.assertEqual((record.type, record.category, record.amount, record.month), expected)


  def test_service_storage_budget_export_and_move(self):
    async def run():
        path = Path(tempfile.mkdtemp()) / "bookkeeping.json"
        service = BookkeepingService(JsonStorage(path), {"timezone": "Asia/Shanghai"})
        await service.storage.load()
        now = datetime.fromisoformat("2026-09-16T10:00:00+08:00")
        record = parse_record("早饭 7.5元", user_id="u", now=now)
        await service.add(record)
        self.assertEqual((await service.summary("u", "2026-09"))["支出"], 7.5)
        self.assertTrue((await service.export("u", "2026-09")).startswith("\ufeff日期,时间"))
        await service.set_budget("u", daily=5)
        self.assertTrue(any("今日已超支" in item for item in await service.check_budget("u", now, record_id=record.id)))
        moved = await service.update("u", "2026-09", 1, "时间", "2026-08-10")
        self.assertEqual(moved.month, "2026-08")
        self.assertEqual(len(await service.list_month("u", "2026-08")), 1)

    asyncio.run(run())


  def test_corrupt_json_recovers(self):
    async def run():
        path = Path(tempfile.mkdtemp()) / "broken.json"
        path.write_text("{broken", encoding="utf-8")
        storage = JsonStorage(path)
        await storage.load()
        self.assertEqual(await storage.all_accounts(), {})
        self.assertTrue(path.with_suffix(".json.broken").exists())

    asyncio.run(run())


if __name__ == "__main__":
  unittest.main()
