from __future__ import annotations

from typing import Any


DEFAULT_CATEGORIES = {
    "餐饮": ["吃", "餐", "饭", "早餐", "午餐", "晚餐", "外卖", "奶茶", "咖啡"],
    "交通": ["车", "打车", "出租", "地铁", "公交", "高铁", "火车", "机票", "加油", "停车"],
    "购物": ["买", "购", "商场", "淘宝", "京东", "拼多多", "衣服", "日用品"],
    "居住": ["房租", "水费", "电费", "燃气", "物业", "家政"],
    "医疗": ["医院", "药", "看病", "医疗", "挂号"],
    "娱乐": ["电影", "游戏", "旅游", "唱歌", "门票", "娱乐"],
    "学习": ["书", "课程", "学费", "培训", "考试", "学习"],
    "人情": ["红包", "礼物", "份子", "请客", "人情"],
    "收入": ["工资", "奖金", "报销", "退款", "利息", "进账", "到账", "赚", "卖"],
    "其他": [],
}


def get_setting(config: Any, key: str, default: Any) -> Any:
    try:
        value = config.get(key, default)
    except AttributeError:
        value = default
    return default if value is None else value


def categories_from(config: Any) -> dict[str, list[str]]:
    raw = get_setting(config, "categories", DEFAULT_CATEGORIES)
    if not isinstance(raw, dict):
        return {k: list(v) for k, v in DEFAULT_CATEGORIES.items()}
    result: dict[str, list[str]] = {}
    for name, words in raw.items():
        if isinstance(words, (list, tuple)):
            result[str(name)] = [str(word) for word in words]
    return result or {k: list(v) for k, v in DEFAULT_CATEGORIES.items()}
