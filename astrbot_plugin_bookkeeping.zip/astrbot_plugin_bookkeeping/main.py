from __future__ import annotations

import asyncio
import re
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from astrbot.api import AstrBotConfig, logger
from astrbot.api.event import AstrMessageEvent, MessageChain, filter
from astrbot.api.message_components import File
from astrbot.api.star import Context, Star, StarTools

from .config import categories_from, get_setting
from .parser import parse_record
from .report import added, error, month_report, query_report, settlement_report, statistics_report
from .service import BookkeepingService
from .storage import JsonStorage
from .utils import local_now, money, parse_month


PLUGIN_NAME = "astrbot_plugin_bookkeeping"
PREFIX_RE = re.compile(r"^\s*[Jj][Zz]\s*[，,]\s*(.+)$")


class BookkeepingPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig) -> None:
        super().__init__(context, config)
        self.config = config
        self.storage: JsonStorage | None = None
        self.service: BookkeepingService | None = None
        self.timezone = ZoneInfo(str(get_setting(config, "timezone", "Asia/Shanghai")))
        self._settlement_task: asyncio.Task | None = None

    async def initialize(self) -> None:
        data_dir = StarTools.get_data_dir(PLUGIN_NAME)
        self.storage = JsonStorage(data_dir / "bookkeeping.json")
        await self.storage.load()
        self.service = BookkeepingService(self.storage, self.config)
        self._settlement_task = asyncio.create_task(self._settlement_loop())

    async def terminate(self) -> None:
        if self._settlement_task:
            self._settlement_task.cancel()
            await asyncio.gather(self._settlement_task, return_exceptions=True)

    @filter.regex(r"^\s*[Jj][Zz](?:\s*[，,]\s*.+|\s*(?:删除|修改|撤销|查|统计|月报|结算|导出|预算)(?:\s+.*)?)\s*$")
    async def on_bookkeeping(self, event: AstrMessageEvent):
        message = self._clean_message(event.get_message_str())
        if not message:
            return
        event.stop_event()
        try:
            response = await self._dispatch(event, message)
        except Exception as exc:
            logger.error(f"Bookkeeping command failed: {exc}")
            response = error("操作失败，请检查输入后重试")
        if response:
            yield event.plain_result(response) if isinstance(response, str) else response

    async def _dispatch(self, event: AstrMessageEvent, message: str):
        service = self._require_service()
        user_id = event.get_sender_id()
        group_id = event.get_group_id() or None
        command_match = re.match(r"^\s*JZ\s*(.*)$", message, re.I)
        body = command_match.group(1).strip() if command_match else message
        if not body:
            return error("内容为空", "JZ，早饭 7.5 元")
        lower = body.lower()
        if lower.startswith("删除"):
            return await self._delete(service, user_id, group_id, body[2:].strip())
        if lower.startswith("修改"):
            return await self._update(service, user_id, group_id, body[2:].strip())
        if lower == "撤销":
            record = await service.undo_last(user_id, group_id)
            return f"✅ 已撤销最近一笔\n{record.note} {record.amount:.2f} 元"
        if lower.startswith("查"):
            return await self._query(service, user_id, group_id, body[1:].strip())
        if lower.startswith("统计"):
            return await self._statistics(service, user_id, group_id, body[2:].strip())
        if lower.startswith("月报"):
            month = parse_month(body[2:].strip() or None)
            records = await service.list_month(user_id, month, group_id)
            return month_report(month, records, await service.summary(user_id, month, group_id), await service.category_summary(user_id, month, "支出", group_id), int(get_setting(self.config, "max_list", 20)))
        if lower.startswith("结算"):
            month = parse_month(body[2:].strip() or None)
            return settlement_report(await service.query_month_settlement(user_id, month, group_id))
        if lower.startswith("预算"):
            return await self._budget(service, user_id, group_id, body[2:].strip())
        if lower.startswith("导出"):
            return await self._export(event, service, user_id, group_id, body[2:].strip())
        if command_match and command_match.group(1).lstrip().startswith(("，", ",")):
            return await self._add(service, user_id, group_id, event.unified_msg_origin, command_match.group(1).lstrip(" ，,"))
        return error("无法识别指令", "JZ，早饭 7.5 元")

    async def _add(self, service, user_id: str, group_id: str | None, umo: str, text: str) -> str:
        record = parse_record(text, user_id=user_id, group_id=group_id, now=local_now(self.timezone.key), categories=categories_from(self.config))
        await service.add(record)
        account = await self._require_storage().get_account(service.key(user_id, group_id))
        account.setdefault("meta", {})["umo"] = umo
        await self._require_storage().save_account(service.key(user_id, group_id), account)
        warnings = await service.check_budget(user_id, datetime.fromisoformat(record.time), group_id, record.id) if get_setting(self.config, "enable_instant_warn", True) else []
        return added(record, await service.summary(user_id, record.month, group_id), warnings)

    async def _delete(self, service, user_id: str, group_id: str | None, argument: str) -> str:
        month = parse_month(None)
        if argument == "最后":
            record = await service.delete_last(user_id, month, group_id)
        else:
            try:
                index = int(argument)
            except ValueError as exc:
                raise ValueError("删除序号必须是数字或“最后”") from exc
            record = await service.delete(user_id, month, index, group_id)
        summary = await service.summary(user_id, month, group_id)
        return f"✅ 已删除第 {argument} 笔\n{record.note} {record.amount:.2f} 元\n本月支出：{summary['支出']:.2f} 元 ｜ 收入：{summary['收入']:.2f} 元"

    async def _update(self, service, user_id: str, group_id: str | None, argument: str) -> str:
        match = re.match(r"^(\d+)\s+(金额|分类|备注|时间|日期|类型)\s+(.+)$", argument, re.S)
        if not match:
            raise ValueError("修改格式：JZ修改 3 金额 8.5")
        index, field, value = int(match.group(1)), match.group(2), match.group(3).strip()
        record = await service.update(user_id, parse_month(None), index, field, value, group_id)
        return f"✅ 已修改第 {index} 笔\n{record.note} {record.amount:.2f} 元（{record.month}）"

    async def _query(self, service, user_id: str, group_id: str | None, argument: str) -> str:
        parts = argument.split()
        month = None
        if parts and (parts[0] in {"本月", "这个月", "上月", "上个月"} or re.fullmatch(r"\d{4}-\d{2}", parts[0])):
            month, parts = parts[0], parts[1:]
        keyword = " ".join(parts)
        filters = {"month": parse_month(month), "keyword": keyword}
        if keyword in {"支出", "收入"}:
            filters = {"month": parse_month(month), "type": keyword}
        if keyword in categories_from(self.config):
            filters = {"month": parse_month(month), "category": keyword}
        records = await service.query(user_id, filters, group_id)
        if not records:
            return "未找到符合条件的记录"
        return query_report(parse_month(month), records, len(records), int(get_setting(self.config, "max_list", 20)))

    async def _statistics(self, service, user_id: str, group_id: str | None, argument: str) -> str:
        parts = argument.split()
        month = parts[0] if parts and (parts[0] in {"本月", "这个月", "上月", "上个月"} or re.fullmatch(r"\d{4}-\d{2}", parts[0])) else None
        type_name = parts[1] if len(parts) > 1 else "支出"
        if type_name not in {"支出", "收入"}:
            type_name = "支出"
        target = parse_month(month)
        records = await service.list_month(user_id, target, group_id)
        return statistics_report(target, records, await service.category_summary(user_id, target, type_name, group_id), type_name)

    async def _budget(self, service, user_id: str, group_id: str | None, argument: str) -> str:
        if not argument:
            account = await self._require_storage().get_account(service.key(user_id, group_id))
            budget = account.get("budget", {})
            return f"本月预算：{float(budget.get('monthly', 0)):.2f} 元\n每日预算：{float(budget.get('daily', 0)):.2f} 元"
        try:
            amount = money(argument)
        except ValueError as exc:
            raise ValueError("预算金额格式不正确") from exc
        budget = await service.set_budget(user_id, monthly=amount, group_id=group_id)
        return f"✅ 已设置本月预算：{budget['monthly']:.2f} 元"

    async def _export(self, event, service, user_id: str, group_id: str | None, argument: str):
        month = argument or None
        content = await service.export(user_id, month, group_id)
        records = await service.list_month(user_id, month, group_id) if month != "全部" else []
        if month == "全部":
            account = await self._require_storage().get_account(service.key(user_id, group_id))
            count = sum(len(items) for items in account.get("records", {}).values())
        else:
            count = len(records)
        if count > 5000:
            return "❌ 数据超过 5000 行，请按月份分批导出"
        filename = f"bookkeeping_{user_id}_{month or local_now(self.timezone.key).strftime('%Y-%m')}.csv"
        path = self._require_storage().path.parent / filename
        path.write_text(content, encoding="utf-8-sig", newline="")
        try:
            return event.chain_result([File(name=filename, file=str(path))])
        except Exception:
            return f"导出完成，共 {count} 条记录。\n{content[:4000]}"

    async def _settlement_loop(self) -> None:
        while True:
            try:
                now = datetime.now(self.timezone)
                yesterday = (now.date() - timedelta(days=1))
                accounts = await self._require_storage().all_accounts()
                for key, account in accounts.items():
                    user_id, group_id = (key[6:], None) if key.startswith("group:") else (key, None)
                    await self._require_service().settle_daily(user_id, yesterday, group_id)
                if now.day == 1:
                    previous = (now.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
                    for key, account in accounts.items():
                        user_id, group_id = (key[6:], None) if key.startswith("group:") else (key, None)
                        current = await self._require_service().query_month_settlement(user_id, previous, group_id)
                        if current.get("settled"):
                            continue
                        report = await self._require_service().settle_month(user_id, previous, group_id)
                        umo = account.get("meta", {}).get("umo")
                        if umo:
                            await self.context.send_message(umo, MessageChain().message(settlement_report(report)))
                await asyncio.sleep(3600)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.error(f"Bookkeeping settlement failed: {exc}")
                await asyncio.sleep(60)

    def _clean_message(self, text: str) -> str:
        first_line = (text or "").splitlines()[0].strip()
        first_line = re.sub(r"^\s*@[^\s]+\s*", "", first_line)
        if PREFIX_RE.match(first_line):
            return first_line
        if re.match(r"^\s*[Jj][Zz]\s*(?:删除|修改|撤销|查|统计|月报|结算|导出|预算)", first_line):
            return first_line
        return ""

    def _require_service(self) -> BookkeepingService:
        if self.service is None:
            raise RuntimeError("记账插件尚未初始化")
        return self.service

    def _require_storage(self) -> JsonStorage:
        if self.storage is None:
            raise RuntimeError("记账插件尚未初始化")
        return self.storage
