from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class RecordType(str, Enum):
    EXPENSE = "支出"
    INCOME = "收入"


@dataclass
class Record:
    id: str
    user_id: str
    group_id: str | None
    amount: float
    type: str
    category: str
    note: str
    raw: str
    time: str
    month: str

    def __post_init__(self) -> None:
        self.amount = round(float(self.amount), 2)
        self.month = self.time[:7]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Record":
        now = datetime.now().astimezone().replace(microsecond=0).isoformat()
        time = str(value.get("time") or now)
        record = cls(
            id=str(value.get("id") or "legacy"),
            user_id=str(value.get("user_id") or ""),
            group_id=value.get("group_id"),
            amount=float(value.get("amount") or 0),
            type=str(value.get("type") or RecordType.EXPENSE.value),
            category=str(value.get("category") or "未分类"),
            note=str(value.get("note") or ""),
            raw=str(value.get("raw") or ""),
            time=time,
            month=str(value.get("month") or time[:7]),
        )
        if value.get("month"):
            record.month = str(value["month"])
        return record


def empty_account() -> dict[str, Any]:
    return {"records": {}, "budget": {"daily": 0.0, "monthly": 0.0}, "settlement": {}, "meta": {}}
