from __future__ import annotations

import csv
import io
import re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from zoneinfo import ZoneInfo


MONEY_QUANT = Decimal("0.01")


def money(value: float | int | str) -> float:
    try:
        number = Decimal(str(value)).quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("金额格式不正确") from exc
    return float(number)


def money_text(value: float | int) -> str:
    return f"{money(value):.2f}"


def local_now(timezone: str = "Asia/Shanghai") -> datetime:
    return datetime.now(ZoneInfo(timezone)).replace(microsecond=0)


def parse_month(value: str | None, now: datetime | None = None) -> str:
    text = (value or "").strip()
    current = now or local_now()
    if not text or text in {"本月", "这个月"}:
        return current.strftime("%Y-%m")
    if text in {"上月", "上个月"}:
        first = current.replace(day=1) - timedelta(days=1)
        return first.strftime("%Y-%m")
    if re.fullmatch(r"\d{4}-\d{2}", text):
        month = int(text[5:])
        if 1 <= month <= 12:
            return text
    raise ValueError("月份格式应为 YYYY-MM")


def parse_date_text(value: str, now: datetime, date_only: bool = False) -> datetime:
    text = value.strip()
    if text in {"今天", "今日"}:
        target = now.date()
    elif text == "昨天":
        target = (now - timedelta(days=1)).date()
    elif text == "前天":
        target = (now - timedelta(days=2)).date()
    elif text == "大前天":
        target = (now - timedelta(days=3)).date()
    else:
        week_match = re.fullmatch(r"(本周|上周)([一二三四五六日天1-7])", text)
        if week_match:
            weekday_text = week_match.group(2)
            weekday = "一二三四五六日".find(weekday_text)
            if weekday < 0:
                weekday = int(weekday_text) - 1
            offset = (now.weekday() - weekday) if week_match.group(1) == "本周" else now.weekday() + 7 - weekday
            target = (now - timedelta(days=offset)).date()
        else:
            full = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", text)
            md = re.fullmatch(r"(\d{1,2})月(\d{1,2})日?", text)
            slash = re.fullmatch(r"(\d{1,2})/(\d{1,2})", text)
            if full:
                target = date(int(full.group(1)), int(full.group(2)), int(full.group(3)))
            elif md or slash:
                match = md or slash
                target = date(now.year, int(match.group(1)), int(match.group(2)))
            else:
                raise ValueError(f"无法识别日期：{text}")
    result = now.replace(year=target.year, month=target.month, day=target.day)
    if date_only:
        result = result.replace(hour=12, minute=0, second=0)
    return result


def csv_text(records: list[dict]) -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(["日期", "时间", "类型", "分类", "金额", "备注"])
    for record in records:
        timestamp = str(record.get("time", ""))
        writer.writerow([
            timestamp[:10], timestamp[11:19], record.get("type", ""),
            record.get("category", ""), money_text(record.get("amount", 0)), record.get("note", ""),
        ])
    return "\ufeff" + output.getvalue()
