from __future__ import annotations

import asyncio
import copy
import json
import os
import shutil
import threading
from pathlib import Path
from typing import Any

from .models import empty_account


class JsonStorage:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._data: dict[str, Any] = {"version": 1, "accounts": {}}
        self._loaded = False

    async def load(self) -> None:
        await asyncio.to_thread(self._load)

    def _load(self) -> None:
        with self._lock:
            if not self.path.exists():
                self._loaded = True
                return
            try:
                with self.path.open("r", encoding="utf-8") as handle:
                    raw = json.load(handle)
                self._data = self._normalize(raw)
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                backup = self.path.with_suffix(self.path.suffix + ".broken")
                try:
                    shutil.copy2(self.path, backup)
                except OSError:
                    pass
                self._data = {"version": 1, "accounts": {}}
            self._loaded = True

    @staticmethod
    def _normalize(raw: Any) -> dict[str, Any]:
        if not isinstance(raw, dict):
            return {"version": 1, "accounts": {}}
        accounts = raw.get("accounts", raw)
        if not isinstance(accounts, dict):
            accounts = {}
        normalized: dict[str, Any] = {}
        for key, account in accounts.items():
            base = empty_account()
            if isinstance(account, dict):
                base.update({k: v for k, v in account.items() if k in base})
                base["records"] = account.get("records", {}) if isinstance(account.get("records", {}), dict) else {}
                base["budget"] = account.get("budget", {}) if isinstance(account.get("budget", {}), dict) else {}
                base["settlement"] = account.get("settlement", {}) if isinstance(account.get("settlement", {}), dict) else {}
                base["meta"] = account.get("meta", {}) if isinstance(account.get("meta", {}), dict) else {}
            normalized[str(key)] = base
        return {"version": 1, "accounts": normalized}

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self._load()

    def _write(self) -> None:
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        with temp.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(self._data, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, self.path)

    async def get_account(self, key: str) -> dict[str, Any]:
        return await asyncio.to_thread(self._get_account, key)

    def _get_account(self, key: str) -> dict[str, Any]:
        with self._lock:
            self._ensure_loaded()
            account = self._data["accounts"].setdefault(str(key), empty_account())
            return copy.deepcopy(account)

    async def save_account(self, key: str, account: dict[str, Any]) -> None:
        await asyncio.to_thread(self._save_account, key, account)

    def _save_account(self, key: str, account: dict[str, Any]) -> None:
        with self._lock:
            self._ensure_loaded()
            self._data["accounts"][str(key)] = copy.deepcopy(account)
            self._write()

    async def all_accounts(self) -> dict[str, dict[str, Any]]:
        return await asyncio.to_thread(self._all_accounts)

    def _all_accounts(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            self._ensure_loaded()
            return copy.deepcopy(self._data["accounts"])
